$(function () {
    $('[data-popup]').on('click', function () {
        var popupName = $(this).data('popup');

        $.ajax({
            type: "GET", //추후 POST로 변경
            url: "ajax-popup.html",
            dataType: "html",
            error: function () {
                alert("통신실패!!!!");
            },
            success: function (res) {
                //console.log(res);
                $(".popup-wrap").html(res);
                $('body').addClass('active-popup');
                $('#' + popupName + 'Popup').addClass('show');

                // common
                $('.popup-close').click(function () {
                    $(this).parents('.popup').hide();
                    $('body').removeClass('active-popup');
                });
                $('.sel-box a').click(function () {
                    $(this).siblings().removeClass('on');
                    $(this).addClass('on');
                });

                // 견적문의
                $('#qtPopup .view-link').click(function () {
                    $('#prvPopup').show();
                });
                $('#qtPopup .popup-footer a').click(function () {
                    $(this).parents('.popup').removeClass('show');
                    $('body').removeClass('active-popup');
                });






            }
        });
    });
});
