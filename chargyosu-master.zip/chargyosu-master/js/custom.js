$(function () {
    new WOW().init();
    // common
    $('.gnb li').mouseenter(function () {
        $('header').addClass('on')
    }); 
    $('.gnb li').mouseleave(function () {
        $('header').removeClass('on')
    }); 
    $('.snb-top').click(function () {
        $('html,body').animate({ scrollTop: 0 }, 400);
        return false;
    });

    // main
    var swiper = new Swiper(".main-spc-swiper", {
        slidesPerView: 1,
        spaceBetween: 40,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        breakpoints: {
            1024: {
                slidesPerView: 3,
                navigation: {
                    nextEl: ".main-spc-swiper .swiper-button-next",
                    prevEl: ".main-spc-swiper .swiper-button-prev",
                },
            },
        },
    });
    var swiper = new Swiper(".main-dlvr-swiper", {
        slidesPerView: 1,
        spaceBetween: 40,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        breakpoints: {
            1024: {
                slidesPerView: 3,
                navigation: {
                    nextEl: ".main-dlvr-swiper .swiper-button-next",
                    prevEl: ".main-dlvr-swiper .swiper-button-prev",
                },
            },
        },
    });

    // guide-domestic
    $('.car-logo-box a').click(function () {
        $(this).addClass('on');
        $(this).siblings().removeClass('on');
    });
    $('.car-list-title .sort a').click(function () {
        $(this).addClass('on');
        $(this).siblings().removeClass('on');
    });

    // 반응형
    $(window).resize(function () {
        if (window.innerWidth < 1024) { 
            // common
            $('.mo-menu').click(function () {
                if ($('header').hasClass('on')) { 
                    $('header').removeClass('on');
                    $('body').removeClass('active-popup');
                } else {
                    $('header').addClass('on');
                    $('body').addClass('active-popup');
                }
            });
            $('.gnb-submenu a').click(function () {
                $('header').removeClass('on');
                $('body').removeClass('active-popup');
            });
        }
    }).resize();
});