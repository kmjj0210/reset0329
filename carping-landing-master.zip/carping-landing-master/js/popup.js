$(function () {
  $(".prv-link").click(function () {
    $(".prv-popup").show();
    $("body").addClass("active-popup");
  });
  $(".popup-close").click(function () {
    $(".popup").hide();
    $("body").removeClass("active-popup");
    return false;
  });
});
