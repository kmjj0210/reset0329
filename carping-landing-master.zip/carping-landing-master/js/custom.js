$(function () {
  new WOW().init();
  var swiper1 = new Swiper(".review-swiper", {
    slidesPerView: 2,
    spaceBetween: 20,
    loop: true,
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
    },
    breakpoints: {
      720: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
    },
  });
  var swiper2 = new Swiper(".card-swiper-top", {
    slidesPerView: 3,
    spaceBetween: 20,
    loop: true,
    autoplay: {
      delay: 2000,
      disableOnInteraction: false,
    },
    breakpoints: {
      720: {
        slidesPerView: 6,
        spaceBetween: 0,
      },
    },
  });
  var swiper3 = new Swiper(".card-swiper-bottom", {
    slidesPerView: 3,
    spaceBetween: 20,
    loop: true,
    autoplay: {
      delay: 2000,
      disableOnInteraction: false,
    },
    breakpoints: {
      720: {
        slidesPerView: 6,
        spaceBetween: 0,
      },
    },
  });
  var swiper4 = new Swiper(".lowest-swiper", {
    slidesPerView: "auto",
    spaceBetween: 20,
    centeredSlides: true,
    loop: true,
    autoplay: {
      delay: 2000,
      disableOnInteraction: false,
    },
    breakpoints: {
      720: {
        slidesPerView: "auto",
        initialSlide: 5,
        spaceBetween: 20,
      },
    },
  });

  // time
  var dDay = new Date();
  dDay.setDate(dDay.getDate() + 30);
  setInterval(function () {
    var now = new Date();
    var distance = dDay - now;
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor(
      (distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
    );
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    $("#day").text(days);
    $("#hours").text(hours);
    $("#mins").text(minutes);
    $("#seconds").text(seconds);
  }, 1000);

  function updateText() {
    if ($(window).width() <= 720) {
      $(".time-txt").text("선착순 마감");
    } else {
      $(".time-txt").text("혜택종료까지 남은 시간");
    }
  }
  updateText();
  $(window).resize(updateText);
});
