$(function () {
    new WOW().init();
    
    $('ul.tabs li').click(function () {
        var tab_id = $(this).attr('data-tab');
        $('ul.tabs li').removeClass('current');
        $('.tab-content').removeClass('current');
        $(this).addClass('current');
        $("#" + tab_id).addClass('current');
    })
    // select custom 
    $('.common-title-style .current').click(function () {
        $(this).parent('.common-title-style').toggleClass('on');
    });
    $('.inq-option').click(function () {
        const text = $(this).html();
        const $selected = $(this).closest('.inq-option-list').prev();
        $selected.html(text);
        $(this).closest('.common-title-style').removeClass('on');
    });
    $(document).on('mouseup',function (f){
        if($('.common-title-style').has(f.target).length === 0){
            $('.common-title-style').removeClass('on');
        }
    });

    // 반응형
    $(window).resize(function () {
        if ($(window).width() < 1024) {
            $('.menu-trigger').click(function () {
                $(this).parents('.gnb').addClass('on');
                $('body').addClass('on');
            });
            $('.menu-trigger-close').click(function () {
                $(this).parents('.gnb').removeClass('on');
                $('body').removeClass('on');
            });
        } else if ($(window).width() < 768) { 
            $('.menu-trigger').click(function () {
                $('body').addClass('fixed');
            });
            $('.menu-trigger-close').click(function () {
                $('body').removeClass('fixed');
            });
        }
    }).resize();
});