$(function () {
    $('.custom-toggle-btn').click(function () {
        $(this).toggleClass('on');
        $(this).next('.custom-toggle').slideToggle();
    });

    // 견적내기 snb
    $('.est-snb-toggle').click(function () {
        $(this).nextAll().slideToggle();
        $(this).toggleClass('on');
    }); 
    $('label.toggle').click(function () {
        $(this).parent().next().slideToggle();
        
        const labelFind = $(this).parents('.est-snb-box').siblings();
        labelFind.find('.top.rd-control').prop("checked",false);
        labelFind.children('.est-snb-sub').slideUp();
    });
    $('.snb-select').click(function () {
        $('.est-snb-cont .rd-control').prop("checked", false);
        $('.est-snb-sub').slideUp();
    });

    // 인기순/차량가/월요금 버튼
    $('.comp-title-top button').click(function () {
        $(this).siblings().removeClass('on'); 
        $(this).addClass('on'); 
    });

    // 선택한 필터
    const selectFilterBtn = $('.sel-filter-box button');
    selectFilterBtn.click(function () {
        $(this).remove();
    });
    $('.sel-all-cancel').click(function () {
        selectFilterBtn.remove();
    });

    // 프로모션 혜택 적용 제품
    var promSwiper = new Swiper(".com-prom-swiper", {
        slidesPerView: 'auto',
        spaceBetween: 15,
        slidesPerGroup: 1,
        centeredSlides: true,
        pagination: {
            el: ".com-prom-swiper .swiper-pagination",
            clickable: true,
        },
        breakpoints: {
            360: {
                spaceBetween: 30,
            },
            768: {
                slidesPerView: 2,
            },
            1400: {
                slidesPerView: 3,
                slidesPerGroup: 3,
                spaceBetween: 30,
                centeredSlides : false,
            },
        },
    });

    // snb------------
    $('.snb-fast-popup .inq-option').click(function () {
        $(this).siblings().removeClass('on'); 
        $(this).addClass('on'); 
    });

    // 글자수
    $('#snbTextBox').keyup(function (e) {
        let content = $(this).val();
        // 글자수 세기
        if (content.length == 0 || content == '') {
            $(this).text('0자');
        } else {
            $('#snbTextCount').text(content.length);
        }
        // 글자수 제한
        if (content.length > 150) {
            $(this).val($(this).val().substring(0, 200));
        };
    });
    $('.snb-fast-cancel').click(function () {
        if ($(this).hasClass('on')) { 
            $('.snb-fast-box').show();
            $(this).removeClass('on')
        } else {
            $('.snb-fast-box').hide();
            $(this).addClass('on')
        }
    });
    // --------------

    // 견적내기 - 금액 버튼
    $('.desc-toggle-btnbox button').click(function () {
        $(this).siblings().removeClass('on')
        $(this).addClass('on')
    });
    $('.est-snb-menu').click(function () {
        $(this).toggleClass('on');
        $('.est-snb-cont').slideToggle(); 
    });

    //빠른 출고 - 링크내 빠른상담 버튼
    $('.fast-item-btn').click(function (e) {
        e.preventDefault();
        e.stopPropagation();
    });
});

