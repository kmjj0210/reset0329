$(function () {
    // 실시간문의
    $('.inq-link-more').click(function () {
        $(this).parent().toggleClass('on');
        $(this).hide();
    });
    $('.inq-more-popup button').click(function () {
        $(this).parent().removeClass('on');
        $(this).parent().prev().removeClass('on');
    });

    // 글쓰기
    $('.inq-view-btn').click(function () {
        $(this).toggleClass('on');
        $(this).next().toggleClass('on');
    });

    $('.faq-toggle-title').click(function () {
        $(this).next().slideToggle();
        $(this).toggleClass('on');
    });

    // 신고하기
    $('.report-link-more').click(function () {
        $(this).parent().addClass('on');
        $(this).hide();
    });

});