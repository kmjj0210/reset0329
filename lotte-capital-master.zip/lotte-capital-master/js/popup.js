$(function () {
    $('[data-popup]').on('click', function () {
        var popupName = $(this).data('popup');

        $.ajax({
            type: "GET", //추후 POST로 변경
            url: "ajax-popup.html",
            dataType: "html",
            error: function () {
                alert("통신실패!!!!");
            },
            success: function (res) {
                //console.log(res);
                $(".popup-wrap").html(res);
                $('body').addClass('on');
                $('#' + popupName + 'Popup').show();
                $('#' + popupName + 'Popup').addClass('on');

                // common
                $('.popup-close , .inquiry-close-btn , .del-popup-btnbox button').click(function () {
                    $(this).parents('.popup').hide();
                    $('body').removeClass('on');
                    return false;
                });

                // 실시간 문의
                // 글자수 함수
                function countText(inputIdName,textId) { 
                    let content = inputIdName.val();
                    // 글자수 세기
                    if (content.length == 0 || content == '') {
                        inputIdName.text('0자');
                    } else {
                        textId.text(content.length);
                    }
                    // 글자수 제한
                    if (content.length > 150) {
                        inputIdName.val(inputIdName.val().substring(0, 200));
                    };
                }
                $('#inquiryPopup #textBox').keyup(function (e) {
                    let inquiryinputIdName = $('#inquiryPopup #textBox');
                    let inquirytextId = $('#inquiryPopup #textCount');
                    countText(inquiryinputIdName,inquirytextId);
                });

                $('.inquiry-ess-sel').click(function () {
                    $('#privacyPopup').show();
                }); 

                $('#inquiryFastPopup .inquiry-ess-sel').click(function () {
                    $('#inquiryFastPopup').addClass('on');
                });

                $('#privacyPopup .popup-close').click(function () {
                    if ($('#inquiryPopup').hasClass('on')) { 
                        $('body').addClass('on');
                    } else if ($('#inquiryFastPopup').hasClass('on')) { 
                        $('body').addClass('on');
                    } 
                });

                // 실시간 문의(빠른문의)
                $('#inquiryFastPopup #textBox').keyup(function (e) {
                    let inquiryinputIdName = $('#inquiryFastPopup #textBox');
                    let inquirytextId = $('#inquiryFastPopup #textCount');
                    countText(inquiryinputIdName,inquirytextId);
                });

                // 상담신청
                $('.req-input-btn').click(function () {
                    $('#privacyPopup').show();
                });

                //맞춤 견적서
                $('.custom-toggle-btn').click(function () {
                    $(this).toggleClass('on');
                    $(this).next('.custom-toggle').slideToggle();
                });
            }
        });
    });
});
