$(function () {
  new WOW().init();

  // common
  $("ul.tab li , .tab a").click(function () {
    const activeTab = $(this).attr("data-tab");
    $(this).addClass("on").siblings().removeClass("on");
    $("#" + activeTab).addClass("on").siblings(".tabcont").removeClass("on");
  });

  // main
  const mainHotSwiper = new Swiper(".main_hot_swiper", {
    slidesPerView: 1,
    spaceBetween: 20,
    pagination: {
      el: ".main_hot_swiper .swiper-pagination",
      clickable: true,
    },
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
    },
    breakpoints: {
      1024: {
        slidesPerView: 2, //브라우저가 1024보다 클 때
      },
    },
  });

  const mainBestSwiper = new Swiper(".main_best_swiper", {
    slidesPerView: 1,
    spaceBetween: 20,
    navigation: {
      nextEl: ".main_best_swiper .swiper-button-next",
      prevEl: ".main_best_swiper .swiper-button-prev",
    },
    autoplay: {
      delay: 1500,
      disableOnInteraction: true,
      pauseOnMouseEnter: true
    },
    breakpoints: {
      1024: {
        slidesPerView: 3,
        spaceBetween: 30, //브라우저가 1024보다 클 때
      },
    },
  });

  const mainEtcSwiper = new Swiper(".main_etc_swiper", {
    pagination: {
      el: ".main_etc_swiper .swiper-pagination",
      clickable: true,
      renderBullet: function (index, className) {
        return '<span class="' + className + '">' + (index + 1) + "</span>";
      },
    },
    navigation: {
      nextEl: ".main_best_swiper .swiper-button-next",
      prevEl: ".main_best_swiper .swiper-button-prev",
    },
    autoplay: {
      delay: 2000,
      disableOnInteraction: false,
    },
  });

  // cs-faq
  $(".faq_cont_list .right_top").click(function () {
    $(this).toggleClass("on").next(".right_bottom").slideToggle();
  });

  // cs-inq
  $(".view_more_box .icon_more").click(function () {
    $(this).next().toggleClass("on");
  });
  $(".view_more_box .more_popup a").click(function () {
    $(this).parent().removeClass("on");
  });

  //estimate-compare
  $(".est_snb_toggle").click(function () {
    $(this).nextAll().slideToggle().end().toggleClass("on");
  });

  $("label.toggle").click(function () {
    $(this).parent().next().slideToggle();
    const labelFind = $(this).parents(".est_snb_box").siblings();
    labelFind.find(".top.rd_control").prop("checked", false);
    labelFind.children(".est_snb_sub").slideUp();
  });

  $(".snb_select").click(function () {
    $(".est_snb_cont .rd_control").prop("checked", false);
    $(".est_snb_sub").slideUp();
  });

  $(document).on("click", ".est_snb.on", function () {
    $("html").scrollTop(0);
  });

  // 인기순/차량가/월요금 버튼
  $(".comp_title_top a").click(function () {
    $(this).siblings().removeClass("on");
    $(this).addClass("on");
  });

  // 선택한 필터
  $(".sel_filter_box > *").click(function () {
    if ($(this).hasClass("sel_all_cancel")) {
      $(this).siblings().remove();
    } else {
      $(this).remove();
    }
  });

  // 프로모션 혜택 적용 제품
  var promSwiper = new Swiper(".com_prom_swiper", {
    slidesPerView: "auto",
    spaceBetween: 15,
    slidesPerGroup: 1,
    centeredSlides: true,
    pagination: {
      el: ".com_prom_swiper .swiper-pagination",
      clickable: true,
    },
    autoplay: {
      delay: 2000,
      disableOnInteraction: false,
    },
    breakpoints: {
      360: {
        spaceBetween: 30
      },
      768: {
        slidesPerView: 2
      },
      1400: {
        slidesPerView: 3,
        slidesPerGroup: 3,
        spaceBetween: 30,
        centeredSlides: false,
      },
    },
  });

  //estimate-compare-desc
  $(".desc_toggle_btnbox a").click(function () {
    $(this).siblings().removeClass("on");
    $(this).addClass("on");
  });
  $(".option_toggle").click(function () {
    $(this).toggleClass("on").next().slideToggle();
  });

  // snb------------
  $(".snb_fast_popup .inq_option").click(function () {
    $(this).siblings().removeClass("on").end().addClass("on");
  });

  // 글자수
  $("#snbTextBox").keyup(function (e) {
    // 글자수 세기
    let content = $(this).val();
    const count = content.length;
    $("#snbTextCount").text(count || "0");
    if (count > 150) $(this).val(content.substring(0, 200));
  });

  $(".snb_fast_cancel").click(function () {
    $(".snb_fast_popup").hide();
  });

  const $est_snb = $(".est_snb");

  // 반응형
  $(window).resize(function () {
    if ($(window).width() < 1024) {
      // header
      $(".header_mo_menu").click(function () {
        $(".header").addClass("on");
        $("body").addClass("active_popup");
      });
      $(".header_mo_close").click(function () {
        $(".header").removeClass("on");
        $("body").removeClass("active_popup");
      });

      // swiper bullet
      $(".swiper-pagination").hide();

      // estimate-compare
      $(window).scroll(function () {
        const height = $(window).scrollTop();
        const $est_snb = $(".est_snb");
        if ($(".cmp_content").length) {
          const descHere = $(".cmp_content").offset().top;
          $est_snb.toggleClass("on", height > descHere);
        }
      });
    } else {
      // swiper bullet
      $(".swiper-pagination").show();

      // estimate-compare
      $(window).scroll(function () {
        const height = $(window).scrollTop();
        const est_snh_height = $est_snb.find(".est_snb_inner").height();
        if (height > est_snh_height + 298) {
          if ($(".sec_est_cmp").length) {
            $est_snb.addClass("on");
          }
          //estimate-compare-desc
          if ($(".sec_est_desc").length) {
            $est_snb.addClass("active");
            $(".option_toggle").addClass("on").next().slideUp();
          }
        } else {
          $est_snb.removeClass("on , active");
        }
      });

    }
  }).resize();
});