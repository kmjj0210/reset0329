$(function () {
    $('[data-popup]').on('click', function () {
        var popupName = $(this).data('popup');

        $.ajax({
            type: "GET", //추후 POST로 변경
            url: "ajax-popup.html",
            dataType: "html",
            error: function () {
                alert("통신실패!!!!");
            },
            success: function (res) {
                //console.log(res);
                $('.popup_wrap').html(res);
                $('body').addClass('active_popup');
                $('#' + popupName + 'Popup').show();

                // common
                $('.popup_close, .popup_close_btn, .del_close_btn button').click(function () {
                    $(this).parents('.popup').hide();
                    $('body').removeClass('active_popup');
                    return false;
                });

                // 개인정보처리방침
                $('.privacy_close').click(function () {
                    $('#privacyPopup').hide();
                    $('body').removeClass('active_popup');
                    return false;
                });

                // 빠른상담
                $('#inquiryFastPopup .ipi_sel').click(function () {
                    $('#privacyPopup').show();
                    $('body').addClass('hide_body');
                });
                function countText(inputIdName,textId) { 
                    let content = inputIdName.val();
                    // 글자수 세기
                    if (content.length == 0 || content == '') {
                        inputIdName.text('0자');
                    } else {
                        textId.text(content.length);
                    }
                    // 글자수 제한
                    if (content.length > 150) {
                        inputIdName.val(inputIdName.val().substring(0, 200));
                    };
                }
                $('#inquiryFastPopup #textBox').keyup(function (e) {
                    let inquiryinputIdName = $('#inquiryFastPopup #textBox');
                    let inquirytextId = $('#inquiryFastPopup #textCount');
                    countText(inquiryinputIdName,inquirytextId);
                });
                $('#inquiryFastPopup .popup_close,#inquiryFastPopup .popup_close_btn').click(function () {
                    $('body').removeClass('hide_body');
                });
                $('.popup .sel_chk_cont a').click(function () {
                    $('#privacyPopup').show();
                });

                //견적서
                $('#estimatePopup .est_popup_btns button, #estimatePopup .popup_close').click(function () {
                    $('#estimatePopup').hide();
                    $('body').removeClass('active_popup , hide_body');
                });
                $('#estimatePopup .sel_chk_cont a').click(function () {
                    $('body').addClass('hide_body');
                }); 










            }
        });
    });
});
